// Your web app's Firebase configuration
const firebaseConfig = {
  // apiKey: process.env.REACT_APP_API_KEY,
  // authDomain: process.env.REACT_APP_AUTH_DOMAIN,
  // projectId: process.env.REACT_APP_PROJECT_ID,
  // storageBucket: process.env.REACT_APP_STORAGE_BUCKET,
  // messagingSenderId: process.env.REACT_APP_MESSAGING_SENDER_ID,
  // appId: process.env.REACT_APP_APP_ID

  apiKey: "AIzaSyCBgzZmOm7uBIRCY4oz7H1PEpiC5X8ZaMw",
  authDomain: "sku-markets-test.firebaseapp.com",
  projectId: "sku-markets-test",
  storageBucket: "sku-markets-test.appspot.com",
  messagingSenderId: "600604001710",
  appId: "1:600604001710:web:ab6253ec1fc4177ce7b43f",
  measurementId: "G-JL7FWBQZ84"
   
};
export default firebaseConfig;