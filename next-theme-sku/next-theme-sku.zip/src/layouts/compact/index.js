export { default } from './CompactLayout';
