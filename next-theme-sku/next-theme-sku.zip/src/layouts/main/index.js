export { default } from './MainLayout';
