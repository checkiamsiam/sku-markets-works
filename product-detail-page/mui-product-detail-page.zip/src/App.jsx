import React from 'react'
import ProductDetails from './pages/productDetails'

function App() {

  return (
    <div>
      <ProductDetails></ProductDetails>
    </div>
  )
}

export default App
